**Simple instruction

To change the language of the game, just enter "language" in the input (the command is same regardless of the current language)
