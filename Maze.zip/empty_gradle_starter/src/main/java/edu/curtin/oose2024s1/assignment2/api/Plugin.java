package edu.curtin.oose2024s1.assignment2.api;

/*
 * AUTHOR: Rivin Pathirage
 * UNIT: Software Architecture and Extensible Design
 * PURPOSE: Structure for plugins
 * REFERENCES: 
 */

//import edu.curtin.oose2024s1.assignment2.*;
//import edu.curtin.oose2024s1.assignment2.gameplugins.*;


import edu.curtin.oose2024s1.assignment2.Game;

public interface Plugin 
{
    void initialize(GameAPI gameAPI);
    String getName();
    String getDescription();

    //The update
    void handleEvent(String event, Game game);
}
