package edu.curtin.oose2024s1.assignment2;

/*
 * AUTHOR: Rivin Pathirage
 * UNIT: Software Architecture and Extensible Design
 * PURPOSE: Handles the UI of the game
 * REFERENCES: 
 */

import java.text.MessageFormat;
import java.util.Locale;
import java.util.ResourceBundle;
import java.util.Scanner;

public class ConsoleUI 
{
    private Game game;
    private ResourceBundle messages;
    private Scanner scanner;

    private int moveCount = 0;

    //The Constructor
    public ConsoleUI(Game game, ResourceBundle messages) 
    {
        this.game = game;
        this.messages = messages;
        this.scanner = new Scanner(System.in);
    }

    //Purpose:Start the Game
    public void start() 
    {
        boolean running = true;
        while (running) 
        {

            clearScreen();

            displayGrid();
            displayInventory();
            String input = promptForInput();
            
            switch (input.toLowerCase()) 
            {
                //Can change input from here
                case "up":
                case "down":
                case "left":
                case "right":
                    game.move(input);
                    moveCount++;
                    break;
                case "teleport":
                    game.teleportPlayer();
                    moveCount++;
                    break;
                case "quit":
                    running = false;
                    break;
                case "language":
                    changeLanguage();
                    break;
                default:
                    System.out.println(messages.getString("invalid_input"));
            }

            if (game.isGameOver()) 
            {
                clearScreen();
                displayGrid();
                System.out.println(messages.getString("game_over"));
                System.out.println(MessageFormat.format(messages.getString("move_count"), moveCount));
                running = false;
            }
        }
    }

    //Purpose: Display the grid
    @SuppressWarnings("PMD.ConfusingTernary")//The conditions used in this method does make sense due to using method "isVisible" Hence it is meaningful and not confusing
    private void displayGrid() 
    {
        Grid grid = game.getGrid();
        Player player = game.getPlayer();
        
        for (int i = 0; i < grid.getRows(); i++) 
        {
            for (int j = 0; j < grid.getCols(); j++) 
            {
                if (i == player.getRow() && j == player.getCol()) 
                {
                    System.out.print("P ");
                } 
                else if (!grid.isVisible(i, j)) 
                {
                    System.out.print("# ");
                } 
                else if (grid.isGoal(i, j)) 
                {
                    System.out.print("G ");
                } 
                else if (grid.hasItem(i, j)) 
                {
                    System.out.print("I ");
                } 
                else if (grid.hasObstacle(i, j)) 
                {
                    System.out.print("O ");
                } 
                else 
                {
                    System.out.print(". ");
                }
            }
            System.out.println();
        }
    }

    //Purpose: Display the inventory
    private void displayInventory() 
    {
        System.out.println(messages.getString("inventory"));
        for (Item item : game.getPlayer().getInventory()) 
        {
            System.out.println("- " + item.getName());
        }
    }

    //Purpose:Get the input from the user
    private String promptForInput() 
    {
        System.out.print(messages.getString("prompt_move"));

        //New
        System.out.println(messages.getString("teleport_option"));
        return scanner.nextLine().trim();
    }

    //Purpose:Change language using the properties files
    private void changeLanguage() 
    {
        System.out.print(messages.getString("prompt_language"));
        String languageTag = scanner.nextLine().trim();
        Locale newLocale = Locale.forLanguageTag(languageTag);
        messages = ResourceBundle.getBundle("translations.messages", newLocale);
        System.out.println(messages.getString("language_changed"));
    }

    //Purpose:Clean the terminals old game fram
    private void clearScreen() 
    {
        System.out.print("\033[H\033[2J");
        System.out.flush();
    }
}
