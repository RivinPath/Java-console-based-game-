package edu.curtin.oose2024s1.assignment2.api;

/*
 * AUTHOR: Rivin Pathirage
 * UNIT: Software Architecture and Extensible Design
 * PURPOSE: Implementation of the GameAPI
 * REFERENCES: 
 */

//import edu.curtin.oose2024s1.assignment2.*;
//import edu.curtin.oose2024s1.assignment2.api.Callback.*;
//import edu.curtin.oose2024s1.assignment2.gameplugins.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import edu.curtin.oose2024s1.assignment2.Game;
import edu.curtin.oose2024s1.assignment2.Item;
import edu.curtin.oose2024s1.assignment2.Obstacle;


    public class GameAPIImpl implements GameAPI 
    {
        private Game game;
        private List<Callback> moveCallbacks = new ArrayList<>();
        private List<Callback> itemAcquisitionCallbacks = new ArrayList<>();
        private Map<String, Callback> menuCallbacks = new HashMap<>();
    
        //The constructor
        public GameAPIImpl(Game game) 
        {
            this.game = game;
        }
    
        //Purpose: get the player's current row
        @Override
        public int getPlayerRow() 
        {
            return game.getPlayer().getRow();
        }
    
        //Purpose: get the player's current column
        @Override
        public int getPlayerCol() 
        {
            return game.getPlayer().getCol();
        }
    
        //Purpose: get the player's inventory
        @Override
        public List<Item> getPlayerInventory() 
        {
            return new ArrayList<>(game.getPlayer().getInventory());
        }
    
        //Purpose: get the player's last acquired item
        @Override
        public Item getLastAcquiredItem() 
        {
            List<Item> inventory = game.getPlayer().getInventory();
            return inventory.isEmpty() ? null : inventory.get(inventory.size() - 1);
        }
    
        //Purpose: move the player by calling the move methos in Game
        @Override
        public void movePlayer(String direction) 
        {
            game.move(direction);
            for (Callback callback : moveCallbacks) 
            {
                callback.execute(this);
            }
        }
    
        //Purpose: get the number of rows in the grid
        @Override
        public int getGridRows() 
        {
            return game.getGrid().getRows();
        }
    
        //Purpose: get the number of columns in the grid
        @Override
        public int getGridCols() 
        {
            return game.getGrid().getCols();
        }
    
        //Purpose: get the visibility of the grid
        @Override
        public boolean isGridSquareVisible(int row, int col) 
        {
            return game.getGrid().isVisible(row, col);
        }
    
        //Purpose: set the visibility of the grid
        @Override
        public void setGridSquareVisible(int row, int col, boolean visible) 
        {
            game.getGrid().setVisible(row, col, visible);
        }
    
        //Purpose: check if the grid has an item
        @Override
        public boolean hasItem(int row, int col) 
        {
            return game.getGrid().getItem(row, col) != null;
        }
    
        //Purpose: check if the grid has an obstacle
        @Override
        public boolean hasObstacle(int row, int col) 
        {
            return game.getGrid().getObstacle(row, col) != null;
        }
    
        //Purpose: check if the current position is the goal
        @Override
        public boolean isGoal(int row, int col) 
        {
            return game.getGrid().isGoal(row, col);
        }
    
        //Purpose: add an item to the grid
        @Override
        public void addItem(String name, int row, int col, String message) 
        {
            Item item = new Item(name, message);
            game.getGrid().addItem(row, col, item);
        }
    
        //Purpose: remove an item from the grid
        @Override
        public void removeItem(int row, int col) 
        {
            game.getGrid().removeItem(row, col);
        }
    
        //Purpose: add an obstacle to the grid
        @Override
        public void addObstacle(int row, int col, List<String> requiredItems) 
        {
            Obstacle obstacle = new Obstacle(requiredItems);
            game.getGrid().addObstacle(row, col, obstacle);
        }
    
        //Purpose: remove an obstacle from the grid
        @Override
        public void removeObstacle(int row, int col) 
        {
            game.getGrid().removeObstacle(row, col);
        }
    
        //Purpose: check if the game is over
        @Override
        public boolean isGameOver() 
        {
            return game.isGameOver();
        }
    
        //Purpose:Add to the call back list
        @Override
        public void registerMoveCallback(Callback callback) 
        {
            moveCallbacks.add(callback);
        }

        //Purpose:When an item is acquired call back
        @Override
        public void registerItemAcquisitionCallback(Callback callback) 
        {
            itemAcquisitionCallbacks.add(callback);
        }

        //Purpose:When menu option is selected store call back
        @Override
        public void registerMenuCallback(String optionName, Callback callback) 
        {
            menuCallbacks.put(optionName, callback);
        }


        //Purpose: Call the teleportPlayer method in Game
        @Override
        public void teleportPlayer() 
        {
            game.teleportPlayer();
        }
    
        //Purpose:Called by the Game class when an item is acquired
        public void notifyItemAcquisition() 
        {
            for (Callback callback : itemAcquisitionCallbacks) 
            {
                callback.execute(this);
            }
        }
    
        //Purpose:called by the UI when a menu option is selected
        public void executeMenuCallback(String optionName) 
        {
            Callback callback = menuCallbacks.get(optionName);
            if (callback != null) 
            {
                callback.execute(this);
            }
        }
    }

