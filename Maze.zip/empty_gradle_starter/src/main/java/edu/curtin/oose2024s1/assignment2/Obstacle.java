package edu.curtin.oose2024s1.assignment2;

/*
 * AUTHOR: Rivin Pathirage
 * UNIT: Software Architecture and Extensible Design
 * PURPOSE: Handles the obstacles in the gameplay
 * REFERENCES: 
 */

import java.text.Normalizer;
import java.util.List;

public class Obstacle 
{
    private List<String> requiredItems;

    //The Constructor
    public Obstacle(List<String> requiredItems) 
    {
        this.requiredItems = requiredItems;
    }

    //Purpose: Check if the player can pass through the obstacle
    public boolean canPass(List<Item> inventory) 
    {
        return requiredItems.stream()
                            .allMatch(requiredItem -> 
                                inventory.stream()
                                         .anyMatch(playerItem -> 
                                             normalizeString(playerItem.getName())
                                                 .equals(normalizeString(requiredItem))
                                         )
                            );
    }

    

    //Purpose:Normalize the string and make it lowercase
    private String normalizeString(String s) 
    {
        return Normalizer.normalize(s, Normalizer.Form.NFKC).toLowerCase();
    }

    

    public List<String> getRequiredItems() 
    {
        return requiredItems;
    }

    
}
