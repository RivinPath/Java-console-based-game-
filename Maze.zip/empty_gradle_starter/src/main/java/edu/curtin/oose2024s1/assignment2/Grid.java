package edu.curtin.oose2024s1.assignment2;

/*
 * AUTHOR: Rivin Pathirage
 * UNIT: Software Architecture and Extensible Design
 * PURPOSE: Handling the 2d grids and the content and the visiblity of the cells
 * REFERENCES: 
 */

//import edu.curtin.oose2024s1.assignment2.gameplugins.*;
//import edu.curtin.oose2024s1.assignment2.api.*;

public class Grid 
{
    private Cell[][] cells;
    private int rows, cols;

    //The Constructor
    public Grid(int rows, int cols) 
    {
        this.rows = rows;
        this.cols = cols;
        cells = new Cell[rows][cols];
        for (int i = 0; i < rows; i++) 
        {
            for (int j = 0; j < cols; j++) 
            {
                cells[i][j] = new Cell();
            }
        }
    }

    public void setGoal(int row, int col) 
    {
        cells[row][col].setGoal(true);
    }

    //Purpose: Add an item to the grid
    public void addItem(int row, int col, Item item) 
    {
        cells[row][col].setItem(item);
    }

    //Purpose: Add an obstacle to the grid
    public void addObstacle(int row, int col, Obstacle obstacle) 
    {
        cells[row][col].setObstacle(obstacle);
    }

    //Purpose: Check if a move is valid
    public boolean isValidMove(int row, int col) 
    {
        return row >= 0 && row < rows && col >= 0 && col < cols && !cells[row][col].hasObstacle();
    }

    //Purpose: Make the surroundings of the player visible
    public void revealSurroundings(int row, int col) 
    {
        for (int i = -1; i <= 1; i++) 
        {
            for (int j = -1; j <= 1; j++) 
            {
                int newRow = row + i;
                int newCol = col + j;
                if (newRow >= 0 && newRow < rows && newCol >= 0 && newCol < cols) 
                {
                    cells[newRow][newCol].setVisible(true);
                }
            }
        }
    }

    //Purpose: Get the item from the grid
    public Item getItem(int row, int col) 
    {
        return cells[row][col].getItem();
    }

    //Purpose: Remove the item from the grid
    public void removeItem(int row, int col) 
    {
        cells[row][col].setItem(null);
    }



    public int getRows() 
    {
        return rows;
    }

    public int getCols() {
        return cols;
    }

    

    //Purpose: Get the obstacle from the grid
    public Obstacle getObstacle(int row, int col) 
    {
        return cells[row][col].getObstacle();
    }

    //Purpose: Remove the obstacle from the grid
    public void removeObstacle(int row, int col) 
    {
        cells[row][col].setObstacle(null);
    }

    //Purpose: Check if the cell is visible
    public boolean isVisible(int row, int col) 
    {
        return cells[row][col].isVisible();
    }

    //Purpose: Make the cell visible
    public void setVisible(int row, int col, boolean visible) 
    {
        cells[row][col].setVisible(visible);
    }

    //Purpose: Check if the cell is the goal
    public boolean isGoal(int row, int col) 
    {
        return cells[row][col].isGoal();
    }
    

    //Purpose: Check if the cell has a collectable item
    public boolean hasItem(int row, int col) 
    {
        return cells[row][col].getItem() != null;
    }

    //Purpose: Check if the cell has an obstacle
    public boolean hasObstacle(int row, int col) 
    {
        return cells[row][col].getObstacle() != null;
    }

    private class Cell 
    {
        private boolean visible = false;
        private boolean isGoal = false;
        private Item item = null;
        private Obstacle obstacle = null;

        // Getters and setters...

        public boolean isVisible() 
        {
            return visible;
        }

        public void setVisible(boolean visible) 
        {
            this.visible = visible;
        }

        public boolean isGoal() 
        {
            return isGoal;
        }

        public void setGoal(boolean goal) 
        {
            isGoal = goal;
        }

        public Item getItem() 
        {
            return item;
        }

        public void setItem(Item item) 
        {
            this.item = item;
        }

        public Obstacle getObstacle() 
        {
            return obstacle;
        }

        public void setObstacle(Obstacle obstacle) 
        {
            this.obstacle = obstacle;
        }

        public boolean hasObstacle() 
        {
            return obstacle != null;
        }
    }
}
