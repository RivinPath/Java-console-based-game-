package edu.curtin.oose2024s1.assignment2;

/*
 * AUTHOR: Rivin Pathirage
 * UNIT: Software Architecture and Extensible Design
 * PURPOSE: Entry point for the program
 * REFERENCES: 
 */


//import edu.curtin.oose2024s1.assignment2.gameplugins.*;
//import edu.curtin.oose2024s1.assignment2.api.*;
import java.io.FileReader;
import java.io.IOException;
import java.util.Locale;
import java.util.ResourceBundle;


/**
 * Use this code to get started on Assignment 2. You are free to modify or replace this file as
 * needed (to fulfil the assignment requirements, of course).
 */
public class App
{
    
        //The Main method
        public static void main(String[] args) 
        {
            if (args.length < 1) 
            {
                System.out.println("Please provide an input file.");
                return;
            }
    
            try 
            {
                InputParser parser = new InputParser(new FileReader(args[0]));
                Game game = parser.parse();
                
                Locale locale = Locale.getDefault();
                //ResourceBundle messages = ResourceBundle.getBundle("translations.messages", locale);
                ResourceBundle messages = ResourceBundle.getBundle("translations.messages", locale);
                
                ConsoleUI ui = new ConsoleUI(game, messages);
                ui.start();
            } 
            catch (IOException e) 
            {
                System.err.println("I/O Error: " + e.getMessage());
            }
        }
        
        //This is the entry to the application
        
        //System.out.println("Empty Gradle Project");
            
        
        
    
}
