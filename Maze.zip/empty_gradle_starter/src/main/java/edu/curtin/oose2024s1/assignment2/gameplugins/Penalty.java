package edu.curtin.oose2024s1.assignment2.gameplugins;

/*
 * AUTHOR: Rivin Pathirage
 * UNIT: Software Architecture and Extensible Design
 * PURPOSE: Handling the penalty function of the gameplay
 * REFERENCES: 
 */

import java.util.Arrays;

import edu.curtin.oose2024s1.assignment2.Game;
import edu.curtin.oose2024s1.assignment2.api.GameAPI;
import edu.curtin.oose2024s1.assignment2.api.Plugin;

public class Penalty implements Plugin 
{
    private GameAPI gameAPI;
    private long lastMoveTime;

    //Purpose: Initialize the penalty function
    @Override
    public void initialize(GameAPI gameAPI) 
    {
        this.gameAPI = gameAPI;
        this.lastMoveTime = System.currentTimeMillis();
    }

    @Override
    public String getName() 
    {
        return "Penalty Plugin";
    }

    @Override
    public String getDescription() 
    {
        return "Adds a penalty obstacle if the player takes too long to move.";
    }

    //Purpose:Call checkPenalty when the player moves
    @Override
    public void handleEvent(String event, Game game) 
    {
        if ("move".equals(event)) 
        {
            checkPenalty();
        }
    }

    //Purpose: check if the player has taken too long to move
    private void checkPenalty() 
    {
        long currentTime = System.currentTimeMillis();
        if (currentTime - lastMoveTime > 5000) 
        { // 5 seconds
            addPenaltyObstacle();
        }
        lastMoveTime = currentTime;
    }

    //Purpose: Adding the penalty obstacle
    private void addPenaltyObstacle() 
    {
        int playerRow = gameAPI.getPlayerRow();
        int playerCol = gameAPI.getPlayerCol();
        int[] adjacentSquare = findAdjacentEmptySquare(playerRow, playerCol);
        
        if (adjacentSquare != null) 
        {
            gameAPI.addObstacle(adjacentSquare[0], adjacentSquare[1], 
                                Arrays.asList("Penalty Removal Tool"));
        }
    }

    //Purpose: Find a near by empty grid
    private int[] findAdjacentEmptySquare(int row, int col) 
    {
        int[][] directions = {{-1, 0}, {1, 0}, {0, -1}, {0, 1}};
        for (int[] dir : directions) 
        {
            int newRow = row + dir[0];
            int newCol = col + dir[1];
            if (isValidSquare(newRow, newCol) && isEmpty(newRow, newCol)) 
            {
                return new int[]{newRow, newCol};
            }
        }
        return null;
    }

    //Purpose: Check the boundary
    private boolean isValidSquare(int row, int col) 
    {
        return row >= 0 && row < gameAPI.getGridRows() && 
               col >= 0 && col < gameAPI.getGridCols();
    }

    //Purpose: check if the grid is empty
    private boolean isEmpty(int row, int col) 
    {
        return !gameAPI.hasItem(row, col) && 
               !gameAPI.hasObstacle(row, col) && 
               !gameAPI.isGoal(row, col);
    }
}
