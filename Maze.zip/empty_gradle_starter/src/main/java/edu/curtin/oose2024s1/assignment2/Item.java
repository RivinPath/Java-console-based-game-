package edu.curtin.oose2024s1.assignment2;

/*
 * AUTHOR: Rivin Pathirage
 * UNIT: Software Architecture and Extensible Design
 * PURPOSE: Handling the collectable items of the gameplay
 * REFERENCES: 
 */

//import edu.curtin.oose2024s1.assignment2.gameplugins.*;
//import edu.curtin.oose2024s1.assignment2.api.*;

public class Item 
{
    private String name;
    private String message;

    //The Constructor
    public Item(String name, String message) 
    {
        this.name = name;
        this.message = message;
    }

    

    public String getName() 
    {
        return name;
    }

    public String getMessage() 
    {
        return message;
    }
}
