package edu.curtin.oose2024s1.assignment2.api;

/*
 * AUTHOR: Rivin Pathirage
 * UNIT: Software Architecture and Extensible Design
 * PURPOSE: Interface with the methods for the plugins and scripts for interacting with the game
 * REFERENCES: 
 */

//import edu.curtin.oose2024s1.assignment2.*;
//import edu.curtin.oose2024s1.assignment2.gameplugins.*;

import java.util.List;

import edu.curtin.oose2024s1.assignment2.Item;

public interface GameAPI 
{
    int getPlayerRow();
    int getPlayerCol();
    List<Item> getPlayerInventory();
    Item getLastAcquiredItem();
    void movePlayer(String direction);
    int getGridRows();
    int getGridCols();
    boolean isGridSquareVisible(int row, int col);
    void setGridSquareVisible(int row, int col, boolean visible);
    boolean hasItem(int row, int col);
    boolean hasObstacle(int row, int col);
    boolean isGoal(int row, int col);
    void addItem(String name, int row, int col, String message);
    void removeItem(int row, int col);
    void addObstacle(int row, int col, List<String> requiredItems);
    void removeObstacle(int row, int col);
    boolean isGameOver();


    /*void registerMoveCallback(Callback callback);
    void registerItemAcquisitionCallback(Callback callback);    
    void registerMenuCallback(String optionName, Callback callback);*/

    void registerMoveCallback(Callback callback);
    void registerItemAcquisitionCallback(Callback callback);
    void registerMenuCallback(String optionName, Callback callback);

    //New
    void teleportPlayer();

}
