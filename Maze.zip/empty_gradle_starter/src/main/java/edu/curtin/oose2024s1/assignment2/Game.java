package edu.curtin.oose2024s1.assignment2;

/*
 * AUTHOR: Rivin Pathirage
 * UNIT: Software Architecture and Extensible Design
 * PURPOSE: Handling the core game logic
 * REFERENCES: 
 */

//import edu.curtin.oose2024s1.assignment2.gameplugins.*;
import edu.curtin.oose2024s1.assignment2.api.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

public class Game 
{
    private Grid grid;
    private Player player;
    private List<Plugin> plugins = new ArrayList<>();
    private Map<String, String> scripts = new HashMap<>();

    private boolean isGameOver = false;

    
    private GameAPI gameAPI;


    //The Constructor
     public Game(int rows, int cols, int startRow, int startCol, int goalRow, int goalCol) 
    {
        this.grid = new Grid(rows, cols);
        this.player = new Player(startRow, startCol);
        grid.setGoal(goalRow, goalCol);
        this.gameAPI = new GameAPIImpl(this);

        //New
        registerTeleportCallback();
    }

    //Purpose: Add a collectable item to the game
    public void addItem(String name, List<int[]> locations, String message) 
    {
        Item item = new Item(name, message);
        for (int[] loc : locations) 
        {
            grid.addItem(loc[0], loc[1], item);
        }
    }

    //Purpose: Add an obstacle to the game
    public void addObstacle(List<int[]> locations, List<String> requiredItems) 
    {
        Obstacle obstacle = new Obstacle(requiredItems);
        for (int[] loc : locations) 
        {
            grid.addObstacle(loc[0], loc[1], obstacle);
        }
    }

    //Purpose:Add a plugin and initialize it with the API
    public void addPlugin(Plugin plugin) 
    {
        plugins.add(plugin);
        plugin.initialize(gameAPI);
    }


    //Purpose: Add a script by storing the content in scripts Hashmap
    public void addScript(String name, String content) 
    {
        scripts.put(name, content);
    }

    //Purpose: Move the player
    public void move(String direction) 
    {
        int[] newPos = player.getNewPosition(direction);
        if (grid.isValidMove(newPos[0], newPos[1])) 
        {
            if (grid.hasObstacle(newPos[0], newPos[1])) 
            {
                Obstacle obstacle = grid.getObstacle(newPos[0], newPos[1]);
                if (obstacle.canPass(player.getInventory())) 
                {
                    performMove(newPos);
                    System.out.println("You passed through an obstacle!");
                } 
                else 
                {
                    System.out.println("You need the following items to pass this obstacle:");
                    for (String item : obstacle.getRequiredItems()) 
                    {
                        System.out.println("- " + item);
                    }
                }
            } 
            else 
            {
                performMove(newPos);
            }
        } 
        else 
        {
            System.out.println("Invalid move. You can't go that way.");
        }
    }


    //Purpose: Moves the player without any checks
    private void performMove(int[] newPos) 
    {
        player.move(newPos[0], newPos[1]);
        grid.revealSurroundings(player.getRow(), player.getCol());
        checkForItem();
        notifyPlugins("move");
        checkForGoal();
    }

    

    //Purpose: Checks if the player has reached the goal
    private void checkForGoal() 
    {
        if (grid.isGoal(player.getRow(), player.getCol())) 
        {
            isGameOver = true;
        }
    }

    //Purpose: Checks if the player has found an item
    private void checkForItem() 
    {
        Item item = grid.getItem(player.getRow(), player.getCol());
        if (item != null) 
        {
            player.addItem(item);
            grid.removeItem(player.getRow(), player.getCol());
            System.out.println("You found: " + item.getName());
            System.out.println(item.getMessage());
            notifyPlugins("item");
        }
    }

    //Purpose: Notifies all plugins
    private void notifyPlugins(String event) 
    {
        for (Plugin plugin : plugins) 
        {
            plugin.handleEvent(event, this);
        }
    }

    //Purpose: Executes a script
    public void executeScript(String scriptName) 
    {
        String scriptContent = scripts.get(scriptName);
        if (scriptContent != null) 
        {
            // Here we would use Jython to execute the script
            // This is a placeholder for the actual implementation
            System.out.println("Executing script: " + scriptName);
            // Actual execution would go here
        }
    }

    //Purpose:Teleport the player using the script
    public void teleportPlayer() 
    {
        Random rand = new Random();
        int newRow, newCol;
        do 
        {
            newRow = rand.nextInt(grid.getRows());
            newCol = rand.nextInt(grid.getCols());
        } 
        while (grid.hasObstacle(newRow, newCol)); // Ensure we don't teleport onto an obstacle

        player.move(newRow, newCol);
        grid.revealSurroundings(newRow, newCol);
        checkForItem();
        notifyPlugins("move");
        checkForGoal();
    }

    //Purpose:Calls back when the teleport option is selected
    private void registerTeleportCallback() 
    {
        gameAPI.registerMenuCallback("Teleport", new Callback() 
        {
            @Override
            public void execute(GameAPI gameAPI) 
            {
                teleportPlayer();
            }
        });
    }

    


    public Grid getGrid() 
    {
        return grid;
    }

    public Player getPlayer() 
    {
        return player;
    }

    public boolean isGameOver() 
    {
        return isGameOver;
    }

    public void setGameOver(boolean gameOver) 
    {
        isGameOver = gameOver;
    }

    public List<Plugin> getPlugins() 
    {
        return plugins;
    }

    public Map<String, String> getScripts() 
    {
        return scripts;
    }

    public GameAPI getGameAPI() 
    {
        return gameAPI;
    }
}
