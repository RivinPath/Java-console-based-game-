package edu.curtin.oose2024s1.assignment2.gameplugins;

/*
 * AUTHOR: Rivin Pathirage
 * UNIT: Software Architecture and Extensible Design
 * PURPOSE: Map of the maze functionality
 * REFERENCES: 
 */

import edu.curtin.oose2024s1.assignment2.Game;
import edu.curtin.oose2024s1.assignment2.Item;
import edu.curtin.oose2024s1.assignment2.api.GameAPI;
import edu.curtin.oose2024s1.assignment2.api.Plugin;
//import edu.curtin.game.Item;


public class Reveal implements Plugin 
{
    private GameAPI gameAPI;

    //Purpose: Initialize the map of the maze function
    @Override
    public void initialize(GameAPI gameAPI) 
    {
        this.gameAPI = gameAPI;
        gameAPI.registerItemAcquisitionCallback(this::checkReveal);
    }

    @Override
    public String getName() 
    {
        return "Reveal Plugin";
    }

    @Override
    public String getDescription() 
    {
        return "Reveals the location of the goal and all hidden items when a map is acquired.";
    }

    //Purpose: Call checkReveal when an item is acquired
    @Override
    public void handleEvent(String event, Game game) 
    {
        if ("item".equals(event)) 
        {
            checkReveal(gameAPI);
        }
    }

    //Purpose: Check if the last acquired item is the map
    private void checkReveal(GameAPI gameAPI) 
    {
        Item lastAcquired = gameAPI.getLastAcquiredItem();
        if (lastAcquired != null && lastAcquired.getName().toLowerCase().contains("map")) 
        {
            revealAll();
        }
    }

    //Purpose: Reveals the location of the goal and all hidden items
    private void revealAll() 
    {
        for (int row = 0; row < gameAPI.getGridRows(); row++) 
        {
            for (int col = 0; col < gameAPI.getGridCols(); col++) 
            {
                if (gameAPI.isGoal(row, col) || gameAPI.hasItem(row, col)) 
                {
                    gameAPI.setGridSquareVisible(row, col, true);
                }
            }
        }
    }
}

