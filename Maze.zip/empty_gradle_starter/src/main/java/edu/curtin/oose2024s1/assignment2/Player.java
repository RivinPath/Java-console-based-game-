package edu.curtin.oose2024s1.assignment2;

/*
 * AUTHOR: Rivin Pathirage
 * UNIT: Software Architecture and Extensible Design
 * PURPOSE: Handling the player in the gameplay
 * REFERENCES: 
 */


//import edu.curtin.oose2024s1.assignment2.gameplugins.*;
//import edu.curtin.oose2024s1.assignment2.api.*;
import java.text.Normalizer;
import java.util.ArrayList;
import java.util.List;

public class Player 
{
    private int row, col;
    private List<Item> inventory = new ArrayList<>();

    //The Constructor
    public Player(int startRow, int startCol) 
    {
        this.row = startRow;
        this.col = startCol;
    }

    //Purpose: Move the player
    public void move(int newRow, int newCol) 
    {
        this.row = newRow;
        this.col = newCol;
    }

    //Purpose:Calculates the new position
    public int[] getNewPosition(String direction) 
    {
        int newRow = row, newCol = col;
        switch (direction.toLowerCase()) 
        {
            //Need to change for better input
            case "up": newRow--; break;
            case "down": newRow++; break;
            case "left": newCol--; break;
            case "right": newCol++; break;
            default:
            throw new IllegalArgumentException("Invalid direction: " + direction);
        }
        return new int[]{newRow, newCol};
    }

    //Purpose: Add item to inventory
    public void addItem(Item item) 
    {
        inventory.add(item);
        System.out.println("Added to inventory: " + item.getName());
    }
    

    public int getRow() 
    {
        return row;
    }

    public int getCol() 
    {
        return col;
    }

    public List<Item> getInventory() 
    {
        return new ArrayList<>(inventory);
    }


    /*public void addItem(Item item) {
        inventory.add(item);
    }*/

    //Purpose:Check for an item in the inventory
    public boolean hasItem(String itemName) 
    {
        String normalizedItemName = normalizeString(itemName);
        return inventory.stream()
                        .map(item -> normalizeString(item.getName()))
                        .anyMatch(name -> name.equals(normalizedItemName));
    }

    //Purpose:Normalize the string and make it lowercase
    private String normalizeString(String s) 
    {
        return Normalizer.normalize(s, Normalizer.Form.NFKC).toLowerCase();
    }
}
