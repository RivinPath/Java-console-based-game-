package edu.curtin.oose2024s1.assignment2.api;

/*
 * AUTHOR: Rivin Pathirage
 * UNIT: Software Architecture and Extensible Design
 * PURPOSE: Handling the callback (Responding to events in the gameplay)
 * REFERENCES: 
 */

//import edu.curtin.oose2024s1.assignment2.*;
//import edu.curtin.oose2024s1.assignment2.gameplugins.*;

@FunctionalInterface //This bitch new
public interface Callback 
{
    void execute(GameAPI gameAPI);
}
