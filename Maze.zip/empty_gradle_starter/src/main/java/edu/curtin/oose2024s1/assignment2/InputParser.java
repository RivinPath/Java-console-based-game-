package edu.curtin.oose2024s1.assignment2;

/*
 * AUTHOR: Rivin Pathirage
 * UNIT: Software Architecture and Extensible Design
 * PURPOSE: Reading the input file
 * REFERENCES: 
 */

//import edu.curtin.oose2024s1.assignment2.gameplugins.*;
//import edu.curtin.oose2024s1.assignment2.api.*;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.Reader;
import java.util.ArrayList;
import java.util.List;

import edu.curtin.oose2024s1.assignment2.api.Plugin;

public class InputParser 
{
    private BufferedReader reader;

    //The Constructor
    public InputParser(Reader input) 
    {
        this.reader = new BufferedReader(input);
    }

    //Purpose: Parse the input file
    public Game parse() throws IOException 
    {
        String line;
        int[] size = null, start = null, goal = null;
        Game game = null;

        while ((line = reader.readLine()) != null) 
        {
            line = line.trim();
            if (line.startsWith("size")) 
            {
                size = parseCoordinates(line);
            } 
            else if (line.startsWith("start")) 
            {
                start = parseCoordinates(line);
            } 
            else if (line.startsWith("goal")) 
            {
                goal = parseCoordinates(line);
            } 
            else if (line.startsWith("item")) 
            {
                if (game == null) 
                {
                    game = createGame(size, start, goal);
                }
                parseItem(game, line);
            } 
            else if (line.startsWith("obstacle")) 
            {
                if (game == null) 
                {
                    game = createGame(size, start, goal);
                }
                parseObstacle(game/* , line*/);
            } 
            else if (line.startsWith("plugin")) 
            {
                if (game == null) 
                {
                    game = createGame(size, start, goal);
                }
                parsePlugin(game, line);
            } 
            else if (line.startsWith("script")) 
            {
                if (game == null) 
                {
                    game = createGame(size, start, goal);
                }
                parseScript(game/*, line*/);
            }
        }

        return game;
    }

    //Purpose:Get the coordinates
    private int[] parseCoordinates(String line) 
    {
        String[] parts = line.split("\\(|\\)")[1].split(",");
        return new int[]{Integer.parseInt(parts[0].trim()), Integer.parseInt(parts[1].trim())};
    }

    //Purpose:Instantiate the game using the coordinated
    private Game createGame(int[] size, int[] start, int[] goal) 
    {
        if (size == null || start == null || goal == null) 
        {
            throw new IllegalStateException("Missing required game parameters");
        }
        return new Game(size[0], size[1], start[0], start[1], goal[0], goal[1]);
    }

    //Purpose:Get item info from the file
    private void parseItem(Game game, String line) throws IOException 
    {
        String name = line.split("\"")[1];
        List<int[]> locations = new ArrayList<>();
        String message = "";

        String nextLine;
        while (!(nextLine = reader.readLine()).contains("}")) 
        {
            if (nextLine.trim().startsWith("at")) 
            {
                locations = parseLocations(nextLine);
            } 
            else if (nextLine.trim().startsWith("message")) 
            {
                message = nextLine.split("\"")[1];
            }
        }

        game.addItem(name, locations, message);
    }

    //Purpose:Return Coordinated from line
    private List<int[]> parseLocations(String line) 
    {
        List<int[]> locations = new ArrayList<>();
        String[] parts = line.split("\\(|\\)");
        for (int i = 1; i < parts.length; i += 2) 
        {
            String[] coords = parts[i].split(",");
            locations.add(new int[]{Integer.parseInt(coords[0].trim()), Integer.parseInt(coords[1].trim())});
        }
        return locations;
    }

    //Purpose:Get obstacle info
    private void parseObstacle(Game game/*, String line*/) throws IOException 
    {
        List<int[]> locations = new ArrayList<>();
        List<String> requiredItems = new ArrayList<>();

        String nextLine;
        while (!(nextLine = reader.readLine()).contains("}")) 
        {
            nextLine = nextLine.trim();
            if (nextLine.startsWith("at")) 
            {
                locations = parseLocations(nextLine);
            } 
            else if (nextLine.startsWith("requires")) 
            {
                requiredItems = parseRequiredItems(nextLine);
            }
        }

        game.addObstacle(locations, requiredItems);
    }

    //Purpose:Get the items needed to go through an obstacle
    private List<String> parseRequiredItems(String line) 
    {
        List<String> items = new ArrayList<>();
        String[] parts = line.split("\"");
        for (int i = 1; i < parts.length; i += 2) 
        {
            items.add(parts[i].trim());
        }
        return items;
    }

    //Purpose:Get the plugin from the input file
    @SuppressWarnings("PMD.AvoidCatchingGenericException")
    //There is no other class of exception that can be used in here except for Exception e, also not having any exception handling is worse hence the decision
    private void parsePlugin(Game game, String line) 
    {
        String className = line.split(" ", 2)[1].trim();
        try 
        {

            
            //className = "edu.curtin.oose2024s1.assignment2.gameplugins." + className;



            Class<?> pluginClass = Class.forName(className);
            Plugin plugin = (Plugin) pluginClass.getDeclaredConstructor().newInstance();
            game.addPlugin(plugin);
        } 
        catch (Exception e) 
        {
            //e.printStackTrace();
            System.out.println("Error: " + e.getMessage());
        }
    }

    //Purpose:Get the script from the input file
    private void parseScript(Game game/*, String line*/) throws IOException 
    {
        StringBuilder scriptContent = new StringBuilder();
        String nextLine;
        while (!(nextLine = reader.readLine()).contains("}")) 
        {
            scriptContent.append(nextLine).append("\n");
        }
        game.addScript("TeleportScript", scriptContent.toString());
    }
}
